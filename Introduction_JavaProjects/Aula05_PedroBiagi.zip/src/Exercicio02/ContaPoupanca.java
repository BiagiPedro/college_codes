package Exercicio02;

public class ContaPoupanca extends Conta{

    public ContaPoupanca(double saldoLiquido) {
        super(saldoLiquido);
    }
}

