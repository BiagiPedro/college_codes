package Exercicio02;
public interface Tributavel {
    public double calculaTributos();
}
