package Exercicio03;

public interface Produto {
    public String id();

    public int anoProducao();

    public String unidadeVenda();

    public String categoria();

    public String preco();


}
