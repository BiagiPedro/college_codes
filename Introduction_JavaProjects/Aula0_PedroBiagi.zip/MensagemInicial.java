public class MensagemInicial {
    public static void main(String[] args) {
        System.out.println("Este é o programa feito em Java!");
    }
}
