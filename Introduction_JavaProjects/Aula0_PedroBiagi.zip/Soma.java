import java.util.Scanner;

public class Soma {
        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            int x1 = sc.nextInt();
            int x2 = sc.nextInt();
            int soma = x1 + x2;
            System.out.println("A soma eh "+soma);
        }


}


